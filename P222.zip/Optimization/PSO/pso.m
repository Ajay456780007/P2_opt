clc;
clear;
close all;
Ts = 5e-6; 
assignin('base', 'Ts', Ts);

if ~exist('Analysis','dir')
    mkdir('Analysis');
end

% Resume logic: check for previous weights
weights_file = fullfile('Analysis','weights_backup.mat');
results_file = fullfile('Analysis','results.mat');

resume = false;
if exist(weights_file, 'file')
    load(weights_file, 'particle', 'GlobalBest', 'BestCost', 'MaxIt', 'nPop', 'VarMin', 'VarMax', 'w', 'c1', 'c2',"VarSize","VelMin","VelMax");
    resume = true;
end

% If not resuming, initialize PSO
if ~resume
    CostFunction = @(x) Obj(x, results_file); % Objective now logs per call
    nVar = 3; 
    VarSize = [1 nVar];
    VarMin = [0.1, 0.01, 1];
    VarMax = [10, 1, 100];
    MaxIt = 1; nPop = 1;
    w = 1; wdamp = 0.99; c1 = 1.5; c2 = 2.0;
    VelMax = 0.1 * (VarMax - VarMin); VelMin = -VelMax;
    
    % Particle initialization (same as your setup, not rerun if resuming)
    empty_particle.Position = [];
    empty_particle.Cost = [];
    empty_particle.Velocity = [];
    empty_particle.Best.Position = [];
    empty_particle.Best.Cost = [];
    particle = repmat(empty_particle, nPop, 1);
    GlobalBest.Cost = inf;
    BestCost = zeros(MaxIt,1);

    for i = 1:nPop
        particle(i).Position = unifrnd(VarMin, VarMax, VarSize);
        particle(i).Velocity = zeros(VarSize);
        particle(i).Cost = CostFunction(particle(i).Position); % Logs values
        particle(i).Best.Position = particle(i).Position;
        particle(i).Best.Cost = particle(i).Cost;
        if particle(i).Best.Cost < GlobalBest.Cost
            GlobalBest = particle(i).Best;
        end
    end
end

% PSO Main Loop (possibly continuing from a saved epoch)
for it = 1:MaxIt
    for i = 1:nPop
        % Usual position/velocity update
        particle(i).Velocity = w * particle(i).Velocity ...
            + c1 * rand(VarSize) .* (particle(i).Best.Position - particle(i).Position) ...
            + c2 * rand(VarSize) .* (GlobalBest.Position - particle(i).Position);
        particle(i).Velocity = max(particle(i).Velocity, VelMin);
        particle(i).Velocity = min(particle(i).Velocity, VelMax);
        particle(i).Position = particle(i).Position + particle(i).Velocity;
        IsOutside = (particle(i).Position < VarMin) | (particle(i).Position > VarMax);
        particle(i).Velocity(IsOutside) = -particle(i).Velocity(IsOutside);
        particle(i).Position = max(particle(i).Position, VarMin);
        particle(i).Position = min(particle(i).Position, VarMax);

        % Objective logs values to mat per epoch
        particle(i).Cost = CostFunction(particle(i).Position);

        if particle(i).Cost < particle(i).Best.Cost
            particle(i).Best.Position = particle(i).Position;
            particle(i).Best.Cost = particle(i).Cost;
            if particle(i).Best.Cost < GlobalBest.Cost
                GlobalBest = particle(i).Best;
            end
        end
    end
    BestCost(it) = GlobalBest.Cost;
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    w = w * wdamp;

    % Save intermediate weights every epoch
    save(weights_file, 'particle', 'GlobalBest', 'BestCost', 'MaxIt', 'nPop', 'VarMin', 'VarMax', 'w', 'c1', 'c2', 'VarSize',"VelMin","VelMax");
end

BestSol = GlobalBest;
% Results summary/plot as in your code



%% Results
figure;
semilogy(BestCost, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;

disp(['Optimized Kp: ', num2str(BestSol.Position(1))]);
disp(['Optimized Ki: ', num2str(BestSol.Position(2))]);
disp(['Optimized Gain: ', num2str(BestSol.Position(3))]);
