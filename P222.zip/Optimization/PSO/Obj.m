function J = Obj(x, results_file)
assignin('base', 'Kp', x(1));
assignin('base', 'Ki', x(2));
assignin('base', 'Gain', x(3));

% Run Simulink simulation
simOut = sim('Proposed.slx', 'SaveOutput', 'on', 'SaveState', 'on', 'ReturnWorkspaceOutputs', 'on');


% Access voltage and current signals from 'out' variable structure in workspace
% voltage_signal = evalin('base', out.Voltage_thd_signal.Data);
% current_signal = evalin('base', out.Current_thd_signal.Data);

voltage_signal=simOut.get("Voltage_thd_signal");
current_signal=simOut.get("Current_thd_signal");

Fs = 50; % Hz

% Calculate THD for voltage and current
thd_voltage = thd(voltage_signal.Data(:), Fs);
thd_current = thd(current_signal.Data(:), Fs);

% Set objective function as sum of THDs
J = thd_voltage + thd_current;

% Save optimization epoch details
results = struct;
results.Kp = x(1);
results.Ki = x(2);
results.Gain = x(3);
results.thd_current = thd_current;
results.thd_voltage = thd_voltage;
results.raw_current = current_signal;
results.raw_voltage = voltage_signal;

% Append results to MAT file
if exist(results_file, 'file') == 2
    S = load(results_file, 'all_results');
    all_results = S.all_results;
    all_results(end+1) = results;
else
    all_results = results;
end
results_file = fullfile(pwd, 'Analysis', 'results.mat');
disp(['Saving results to ', results_file]);
save(results_file, 'all_results', '-v7.3');
 
     
end
